const ENDPOINT = 'https://wirehaired-flowery-fuschia.glitch.me';
const obterRetornoAPI = async () => {
        const response = await fetch('ENDPOINT');
        const dados =  await response.json();
        console.log(dados);
        const conteudo = document.querySelector('.conteudo')
        for(d of dados.data) {
            conteudo.innerHTML += <div>${d}</div>
        }
};