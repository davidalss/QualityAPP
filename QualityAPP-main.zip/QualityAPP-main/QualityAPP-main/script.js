// Função para definir a data atual no campo
function setCurrentDate() {
    const dataInput = document.getElementById('data');
    const currentDate = new Date().toLocaleDateString('pt-BR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
    });
    dataInput.value = currentDate; // Define o valor do campo de data
}

// Chama a função ao carregar a página
window.onload = function() {
    setCurrentDate();
    document.getElementById('campos-gerados').style.display = 'none'; // Garante que o container esteja oculto inicialmente
};

const canvas = document.getElementById("backgroundCanvas");
const ctx = canvas.getContext("2d");

// Ajuste o canvas para cobrir a tela inteira
function resizeCanvas() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
}
resizeCanvas();
window.addEventListener("resize", resizeCanvas);

// Cria partículas para o efeito de fundo
const particlesArray = [];
const colors = ["#0a0a0a", "#1c1c1c", "#2e2e2e", "#3f3f3f"];

class Particle {
    constructor() {
        this.x = Math.random() * canvas.width;
        this.y = Math.random() * canvas.height;
        this.size = Math.random() * 80 + 20;
        this.speedX = Math.random() * 1 - 0.5;
        this.speedY = Math.random() * 1 - 0.5;
        this.color = colors[Math.floor(Math.random() * colors.length)];
    }

    update() {
        this.x += this.speedX;
        this.y += this.speedY;

        if (this.x + this.size > canvas.width || this.x - this.size < 0) {
            this.speedX *= -1;
        }
        if (this.y + this.size > canvas.height || this.y - this.size < 0) {
            this.speedY *= -1;
        }
    }

    draw() {
        ctx.beginPath();
        ctx.fillStyle = this.color;
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        ctx.fill();
    }
}

function initParticles() {
    particlesArray.length = 0;
    for (let i = 
